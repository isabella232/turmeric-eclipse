
package ebayopensource.apis.eblbasecomponents;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 				Basic success/failure response
 * 			
 * 
 * <p>Java class for CSUpdateMACActivityAddAttachmentsResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CSUpdateMACActivityAddAttachmentsResponseType">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:ebayopensource:apis:eBLBaseComponents}AbstractResponseType">
 *       &lt;sequence>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CSUpdateMACActivityAddAttachmentsResponseType")
public class CSUpdateMACActivityAddAttachmentsResponseType
    extends AbstractResponseType
{


}
