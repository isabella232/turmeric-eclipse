@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ebayopensource.org/turmeric/common/v1/types", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.ebayopensource.turmeric.common.v1.types;
