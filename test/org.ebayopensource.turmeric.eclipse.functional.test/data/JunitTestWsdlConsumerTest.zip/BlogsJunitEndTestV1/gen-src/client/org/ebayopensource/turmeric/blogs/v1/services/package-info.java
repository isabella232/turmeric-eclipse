@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ebayopensource.org/turmeric/blogs/v1/services", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.ebayopensource.turmeric.blogs.v1.services;
