
package org.ebayopensource.turmeric.blogs.v1.services.calcservice.impl;

import org.ebayopensource.turmeric.blogs.v1.services.Inparams;
import org.ebayopensource.turmeric.blogs.v1.services.Response;
import org.ebayopensource.turmeric.blogs.v1.services.calcservice.BlogsCalcServiceV1;

public class BlogsCalcServiceV1Impl
    implements BlogsCalcServiceV1
{


    public Response add(Inparams param0) {
        return null;
    }

}
