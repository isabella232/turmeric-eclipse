
/**
 * BlogsCalcServiceV1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6-wso2v2  Built on : Oct 25, 2010 (02:27:59 MST)
 */
    package org.ebayopensource.turmeric.blogs.v1.services.calcservice;
    /**
     *  BlogsCalcServiceV1 java skeleton interface for the axisService
     */
    public interface BlogsCalcServiceV1 {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param inparams
         */

        
                public org.ebayopensource.turmeric.blogs.v1.services.Response add
                (
                  org.ebayopensource.turmeric.blogs.v1.services.Inparams inparams
                 )
            ;
        
         }
    