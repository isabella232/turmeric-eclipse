
/**
 * BlogsCSAPIInterfaceServiceV1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6-wso2v2  Built on : Oct 25, 2010 (02:27:59 MST)
 */
    package ebayopensource.apis.eblbasecomponents.csapiinterfaceservice;
    /**
     *  BlogsCSAPIInterfaceServiceV1 java skeleton interface for the axisService
     */
    public interface BlogsCSAPIInterfaceServiceV1 {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param cSUpdateMACActivityAddAttachmentsRequest
         */

        
                public ebayopensource.apis.eblbasecomponents.CSUpdateMACActivityAddAttachmentsResponseType cSUpdateMACActivityAddAttachments
                (
                  ebayopensource.apis.eblbasecomponents.CSUpdateMACActivityAddAttachmentsRequestType cSUpdateMACActivityAddAttachmentsRequest
                 )
            ;
        
         }
    