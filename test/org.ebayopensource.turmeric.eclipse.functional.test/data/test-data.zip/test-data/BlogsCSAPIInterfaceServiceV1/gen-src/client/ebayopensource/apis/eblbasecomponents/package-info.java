@javax.xml.bind.annotation.XmlSchema(namespace = "urn:ebayopensource:apis:eBLBaseComponents", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ebayopensource.apis.eblbasecomponents;
