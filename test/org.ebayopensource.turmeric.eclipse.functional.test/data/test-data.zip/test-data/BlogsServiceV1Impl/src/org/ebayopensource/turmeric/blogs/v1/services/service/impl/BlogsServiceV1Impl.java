
package org.ebayopensource.turmeric.blogs.v1.services.service.impl;

import org.ebayopensource.turmeric.blogs.v1.services.GetVersionRequest;
import org.ebayopensource.turmeric.blogs.v1.services.GetVersionResponse;
import org.ebayopensource.turmeric.blogs.v1.services.service.BlogsServiceV1;

public class BlogsServiceV1Impl
    implements BlogsServiceV1
{


    public GetVersionResponse getVersion(GetVersionRequest param0) {
        return null;
    }

}
