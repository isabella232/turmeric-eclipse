
/**
 * BlogsServiceV1.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6-wso2v2  Built on : Oct 25, 2010 (02:27:59 MST)
 */
    package org.ebayopensource.turmeric.blogs.v1.services.service;
    /**
     *  BlogsServiceV1 java skeleton interface for the axisService
     */
    public interface BlogsServiceV1 {
     
         
        /**
         * Auto generated method signature
         * Documentation goes here.
                                    * @param getVersionRequest
         */

        
                public org.ebayopensource.turmeric.blogs.v1.services.GetVersionResponse getVersion
                (
                  org.ebayopensource.turmeric.blogs.v1.services.GetVersionRequest getVersionRequest
                 )
            ;
        
         }
    