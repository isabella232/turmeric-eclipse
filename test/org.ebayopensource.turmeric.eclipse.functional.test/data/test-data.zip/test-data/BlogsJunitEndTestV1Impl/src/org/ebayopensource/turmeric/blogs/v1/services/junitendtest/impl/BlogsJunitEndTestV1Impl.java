
package org.ebayopensource.turmeric.blogs.v1.services.junitendtest.impl;

import org.ebayopensource.turmeric.blogs.v1.services.Inparams;
import org.ebayopensource.turmeric.blogs.v1.services.Response;
import org.ebayopensource.turmeric.blogs.v1.services.junitendtest.BlogsJunitEndTestV1;

public class BlogsJunitEndTestV1Impl
    implements BlogsJunitEndTestV1
{


    public Response add(Inparams param0) {
        return null;
    }

}
