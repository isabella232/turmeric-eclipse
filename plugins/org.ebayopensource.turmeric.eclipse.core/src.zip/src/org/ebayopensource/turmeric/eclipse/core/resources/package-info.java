/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.core.resources;