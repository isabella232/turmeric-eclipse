/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.validator.utils.common;