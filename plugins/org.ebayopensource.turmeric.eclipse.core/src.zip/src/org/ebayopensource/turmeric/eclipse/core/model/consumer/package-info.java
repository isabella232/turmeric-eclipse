/**
 * Provides...
 */
package org.ebayopensource.turmeric.eclipse.core.model.consumer;