/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.validator.resources;