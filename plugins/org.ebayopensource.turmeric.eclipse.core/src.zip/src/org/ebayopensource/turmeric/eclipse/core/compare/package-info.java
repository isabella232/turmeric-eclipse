/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.core.compare;