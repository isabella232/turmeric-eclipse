/**
 * Provides...
 */
package org.ebayopensource.turmeric.eclipse.core.logging.system;