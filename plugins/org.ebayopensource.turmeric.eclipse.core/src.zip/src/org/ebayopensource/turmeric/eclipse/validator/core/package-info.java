/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.validator.core;