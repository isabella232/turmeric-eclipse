/**
 * 
 */
package org.ebayopensource.turmeric.eclipse.core.exception;