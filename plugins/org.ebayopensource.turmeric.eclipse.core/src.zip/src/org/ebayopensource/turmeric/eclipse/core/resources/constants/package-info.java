/**
 * Provides...
 */
package org.ebayopensource.turmeric.eclipse.core.resources.constants;